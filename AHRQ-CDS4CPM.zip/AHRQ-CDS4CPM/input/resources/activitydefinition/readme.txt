The 'cqf.fhir.template' template introduces support and convention for this
resource-type-specific subdirectory.
