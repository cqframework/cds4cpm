By convention, a resources directory is expected for the resource scanning performed by the publisher.
As other resource-type-specific subdirectories of resources/ become useful, they
should be added to this this starter IG along with the corresponding Parameter entry
in the ig-starter.xml file. 
