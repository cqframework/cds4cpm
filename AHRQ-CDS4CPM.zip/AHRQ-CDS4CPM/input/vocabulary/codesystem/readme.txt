The vocabulary directory is supported by default by the 'fhir.base.template' template.
The 'cqf.fhir.template' template introduces support and convention for vocabulary/codesystem
for codesystem resources.
