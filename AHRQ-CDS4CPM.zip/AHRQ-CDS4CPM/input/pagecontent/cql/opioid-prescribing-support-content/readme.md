# Opioid Prescribing Support Content

CQL libraries in this folder were copied from the opioid-cds-r4 IG, develop branch, 5/1/2020:
https://github.com/cqframework/opioid-cds-r4/tree/develop/input/pagecontent/cql

Content needs to be updated as changes are made to the master content there.
That IG is close to a release, 2.0.0, refresh this content when that release is made.
