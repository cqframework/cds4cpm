# Pain Management Dashboard Content

The CQL libraries and value set content here were copied from the Pain Management Summary as of 5/1/2020 (v0.3.2):

https://github.com/AHRQ-CDS/AHRQ-CDS-Connect-PAIN-MANAGEMENT-SUMMARY/tree/master/src/cql

Any subsequent changes should be incorporated as they become available.
