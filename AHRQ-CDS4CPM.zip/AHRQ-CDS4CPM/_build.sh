#!/bin/bash
#./_updateRefreshIG.sh -y
#./_refresh.sh
./_updatePublisher.sh -f -y
./_genonce.sh -tx n/a
